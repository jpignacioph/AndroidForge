# SmartScan Browser (Android)

A starter Android browser built with Kotlin, Android WebView, CameraX and Google ML Kit.

## Included
- Web browsing with URL/search bar, back, forward, home and reload
- WebView JavaScript and DOM storage enabled
- Runtime camera permission and WebView camera (`getUserMedia`) permission handling for HTTPS pages
- Built-in camera scanner for QR codes and common 1D/2D barcodes (ML Kit all-formats mode)
- Basic file download support through Android DownloadManager

## Build the APK
1. Install the latest stable **Android Studio** on Windows, macOS or Linux.
2. Open this folder (`SmartScanBrowser`) in Android Studio.
3. Allow Android Studio to install the Android SDK Platform 35 and required build tools.
4. Wait for Gradle sync to finish. An internet connection is needed for the first dependency download.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally created at:
   `app/build/outputs/apk/debug/app-debug.apk`

For a release APK, use **Build > Generate Signed Bundle / APK** and create a signing key.

## Notes
- Camera access is supported for secure HTTPS websites. Many browsers block camera access on ordinary HTTP pages.
- Android will ask for camera permission when a website or the scanner first requests it.
- This starter app is not yet a full Chrome replacement: tab management, bookmarks, history, private browsing, pop-up handling and advanced download/file-upload flows are not included.
- Test camera access on a physical Android phone. Emulator camera behavior varies.
- The debug APK is not prebuilt in this package; build it using Android Studio as described above.
